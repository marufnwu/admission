<?php
    use PHPMailer\PHPMailer\PHPMailer;

    if (isset($_POST['gurdianName']) && isset($_POST['gurdianEmail'])) {
        $gurdianName = $_POST['gurdianName'];
        $gurdianEmail = $_POST['gurdianEmail'];
        $childName = $_POST['childName'];
        $childAge = $_POST['childAge'];
        $message = $_POST['message'];
        $info = "<html>
                    <body>
                        <table  border='1' cellspacing='3' width='100%'>
                            <tr>
                                <td>Gurdian Name:</td>
                                <td>$gurdianName</td>
                            </tr>
                            <tr>
                                <td>Gurdian Email:</td>
                                <td>$gurdianEmail</td>
                            </tr>
                            <tr>
                                <td>Child Name:</td>
                                <td>$childName</td>
                            </tr>
                            <tr>
                                <td>Child Age:</td>
                                <td>$childAge</td>
                            </tr>
                            <tr>
                                <td>Message:</td>
                                <td>$message</td>
                            </tr>
                        </table>
                    </body>
                </html>";

        require_once "PHPMailer/PHPMailer.php";
        require_once "PHPMailer/SMTP.php";
        require_once "PHPMailer/Exception.php";

        $mail = new PHPMailer();

        //SMTP Settings
        $mail->isSMTP();
        $mail->Host = "admission.mysunshineworld.org";
        $mail->SMTPAuth = true;
        $mail->Username = "join@admission.mysunshineworld.org"; 
        $mail->Password = 'c6-@phm*GnCU'; 
        $mail->Port = 465;
        $mail->SMTPSecure = "ssl";

        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom('join@admission.mysunshineworld.org');
        $mail->addAddress("Chandandeep.kaur@mysunshineworld.org"); //enter you email address
        $mail->Subject = ("New Admission Lead from $gurdianName");
        $mail->Body = $info;

        if ($mail->send()) {
            $status = "success";
            $response = "Email is sent!";
        } else {
            $status = "failed";
            $response = "Something is wrong: <br><br>" . $mail->ErrorInfo;
        }

        exit(json_encode(array("status" => $status, "response" => $response)));
    }
    
    
    if (isset($_POST['gurdianNameSec']) && isset($_POST['gurdianEmailSec'])) {
        $gurdianNameSec = $_POST['gurdianNameSec'];
        $gurdianEmailSec = $_POST['gurdianEmailSec'];
        $childNameSec = $_POST['childNameSec'];
        $childAgeSec = $_POST['childAgeSec'];
        $messageSec = $_POST['messageSec'];
        $infoSec = "<html>
                    <body>
                        <table  border='1' cellspacing='3' width='100%'>
                            <tr>
                                <td>Gurdian Name:</td>
                                <td>$gurdianNameSec</td>
                            </tr>
                            <tr>
                                <td>Gurdian Email:</td>
                                <td>$gurdianEmailSec</td>
                            </tr>
                            <tr>
                                <td>Child Name:</td>
                                <td>$childNameSec</td>
                            </tr>
                            <tr>
                                <td>Child Age:</td>
                                <td>$childAgeSec</td>
                            </tr>
                            <tr>
                                <td>Message:</td>
                                <td>$messageSec</td>
                            </tr>
                        </table>
                    </body>
                </html>";

        require_once "PHPMailer/PHPMailer.php";
        require_once "PHPMailer/SMTP.php";
        require_once "PHPMailer/Exception.php";

        $mail_new = new PHPMailer();

        //SMTP Settings
        // $mail_new->SMTPDebug = 3;
        $mail_new->isSMTP();
        $mail_new->Host = "admission.mysunshineworld.org";
        $mail_new->SMTPAuth = true;
        $mail_new->Username = "join@admission.mysunshineworld.org"; 
        $mail_new->Password = 'c6-@phm*GnCU'; 
        $mail_new->Port = 465;
        $mail_new->SMTPSecure = "ssl";

        //Email Settings
        $mail_new->isHTML(true);
        $mail_new->setFrom('join@admission.mysunshineworld.org');
        $mail_new->addAddress("Chandandeep.kaur@mysunshineworld.org"); //enter you email address
        $mail_new->Subject = ("New Admission Lead from $gurdianNameSec");
        $mail_new->Body = $infoSec;

        if ($mail_new->send()) {
            $status_new = "success";
            $response_new = "Email is sent!";
        } else {
            $status_new = "failed";
            $response_new = "Something is wrong: <br><br>" . $mail_new->ErrorInfo;
        }

        exit(json_encode(array("status" => $status_new, "response" => $response_new)));
    }

